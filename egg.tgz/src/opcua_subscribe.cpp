// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Subscribe to nodes"); }
int main(){
  announce();
  return lionss_run_workload("opcua_subscribe");
}
