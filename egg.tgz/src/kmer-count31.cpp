// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Count 31-mers"); }
int main(){
  announce();
  return lionss_run_workload("kmer-count31");
}
