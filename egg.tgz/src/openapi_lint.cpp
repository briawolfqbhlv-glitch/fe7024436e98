// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lint OpenAPI contract\n", stdout);
  return lionss_run_workload("openapi_lint");
}
