// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Align short reads"); }
int main(){
  announce();
  return lionss_run_workload("bwa-align");
}
