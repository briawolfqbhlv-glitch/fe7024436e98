// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Prune snapshots");
  std::fflush(stdout);
  return lionss_run_workload("restic_prune");
}
