// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Migrate hash slots\n", stdout);
  return lionss_run_workload("redis_slotmove");
}
