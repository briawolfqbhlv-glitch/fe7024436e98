// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Temper quillon guard"); }
int main(){
  announce();
  return lionss_run_workload("Quillon");
}
